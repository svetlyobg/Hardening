# V-220707 - The Windows 10 system must use an anti-virus program

Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct